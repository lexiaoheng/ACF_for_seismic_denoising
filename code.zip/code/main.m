clc;
clear all;
addpath('matlab_func/');
addpath('data/')
addpath('evaluate_func/');
%%
load data/in/line1.mat;
noisy = data;

%% 

mi = min(min(data));
ma = max(max(data));
data = (data-mi)./(ma-mi);

scale = 2;
tic
data = iteration(data,scale);
toc
data = data*(ma-mi)+mi;

%%
subplot(1,3,1);
imagesc(noisy);
clim([-30000 30000]);
subplot(1,3,2);
imagesc(data);
clim([-30000 30000]);
subplot(1,3,3);
imagesc(noisy-data);
clim([-30000 30000]);

fprintf('Average local similarity (ALS): %f \n', mean2(localsimi(data,noisy-data,[5,5,1],20,0,0)));

%%
load loss;
fprintf('Learnable parameters: %d \n', params);
delete('./loss.mat');

